class SocketService {}

export default new SocketService();
