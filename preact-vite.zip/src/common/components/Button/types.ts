export interface ButtonProps {
    onClick: () => void;
    className?: string;
}
