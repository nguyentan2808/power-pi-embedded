export interface Lorem {}
